<?php

namespace SITC\Sinchimport\Logger;

/**
 * Class Logger
 * @package SITC\Sinchimport\Logger
 */
class Logger extends \Monolog\Logger
{
}
